# ChatGPT Bot for Lark Việt Nam (Vercel)

## Cách dùng:
1. Đổi tên `.env.example` thành `.env`
2. Điền `OPENAI_API_KEY`, `APP_ID`, `APP_SECRET`
3. Deploy lên Vercel
4. Dán URL webhook vào Lark Developer

/api/webhook sẽ xử lý tin nhắn từ Lark và trả lời bằng ChatGPT.
